var g_tit = "";

//~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*	
$( document ).ready(function() {
    g_tit = "Módulo de Gestión Técnica";
        
    document.title = g_tit;
    $("#tit1").html(g_tit);
    $("#sub-titulo1").html("Creación de Inspección");
    $("#sub-titulo2").html("Captura de Inspección para Cliente Existente");
    $("#sub-titulo3").html("Captura de Inspección en Predio sin Contrato");
    
    
    $( "button" ).button();
    
        $( "#co_cliente" ).button({
		icons: {
			primary: "ui-icon-person"
		},
         label:"CLIENTE EXISTENTE"
        });
    
        $( "#co_no_cliente" ).button({
		icons: {
			primary: "ui-icon-contact"
		},
         label:"PREDIO SIN CONTRATO"
        });	
    
        $( "#co_guardar1" ).button({
		icons: {
			primary: "ui-icon-disk"
		},
         label:"Guardar"
        });	
    
        $( "#co_volver1" ).button({
		icons: {
			primary: "ui-icon-arrowreturnthick-1-w"
		},
         label:"Volver"
        });	
    
        $( "#co_guardar2" ).button({
		icons: {
			primary: "ui-icon-disk"
		},
         label:"Guardar"
        });	
    
        $( "#co_volver2" ).button({
		icons: {
			primary: "ui-icon-arrowreturnthick-1-w"
		},
         label:"Volver"
        });
    
        $( "#co_leer" ).button({
          icons: false,
         label:"Leer"
        });	
    
    $("button").on("click", function(){
        var whatForm = $(this).attr("rel");
        $("#buttons").slideUp();
        
        $("#"+whatForm).slideDown();
        if(whatForm=="form1") $("#tx_cliente").focus();
        if(whatForm=="form2") $("#tx_nom_ref").focus();
        $(".panel_opt").slideUp();
    });

    $(".co_button").on("click", function(e){
        e.preventDefault();
        $("#buttons").slideDown();
        $(".form").slideUp();
        $(".panel_opt").slideDown();
    });

});
